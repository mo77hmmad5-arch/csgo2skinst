import { Prisma, PrismaClient } from "@prisma/client";
import { AppError } from "../lib/errors.js";
import { pickItem, rollPpm } from "../lib/odds.js";
import { lockWallet, postEntry } from "./ledger.js";

async function findExisting(prisma: PrismaClient | Prisma.TransactionClient, userId: string, key: string) {
  return prisma.caseOpening.findUnique({
    where: { userId_idempotencyKey: { userId, idempotencyKey: key } },
    include: { skin: true },
  });
}

/**
 * فتح صندوق. كل شيء في معاملة واحدة:
 * قفل المحفظة ← التحقق ← خصم السعر في الدفتر ← السحب العشوائي ← إضافة العنصر للمخزون ← تسجيل النتيجة.
 * إعادة الإرسال بنفس idempotencyKey تُرجع النتيجة نفسها دون خصم ثانٍ.
 */
export async function openCase(
  prisma: PrismaClient,
  input: { userId: string; caseId: string; idempotencyKey: string },
) {
  const { userId, caseId, idempotencyKey } = input;
  if (!idempotencyKey || idempotencyKey.length > 100) {
    throw new AppError("BAD_IDEMPOTENCY_KEY", "Idempotency key required");
  }

  const existing = await findExisting(prisma, userId, idempotencyKey);
  if (existing) return { opening: existing, replayed: true };

  try {
    const opening = await prisma.$transaction(async (tx) => {
      const user = await tx.user.findUniqueOrThrow({ where: { id: userId } });
      if (user.status !== "ACTIVE") throw new AppError("USER_RESTRICTED", "Account restricted", 403);
      if (!user.ageVerifiedAt) throw new AppError("AGE_NOT_VERIFIED", "Age verification required", 403);

      const box = await tx.case.findUnique({
        where: { id: caseId },
        include: { currentVersion: { include: { items: { include: { skin: true } } } } },
      });
      const version = box?.currentVersion;
      const now = new Date();
      if (!box || !version || !box.isPublished || (box.publishAt && box.publishAt > now)) {
        throw new AppError("CASE_UNAVAILABLE", "Case unavailable", 404);
      }

      const wallet = await lockWallet(tx, userId);
      const spent = version.price;
      const opId = crypto.randomUUID();

      const { entry } = await postEntry(tx, wallet, {
        type: "CASE_PURCHASE",
        amount: -spent,
        idempotencyKey: `open:${userId}:${idempotencyKey}`,
        refType: "CaseOpening",
        refId: opId,
        meta: { caseId, caseVersionId: version.id },
      });

      const roll = rollPpm();
      const won = pickItem(version.items, roll);

      const inv = await tx.inventoryItem.create({
        data: { userId, skinId: won.skinId, source: "CASE_OPENING" },
      });

      return tx.caseOpening.create({
        data: {
          id: opId,
          userId,
          caseVersionId: version.id,
          price: spent,
          rollPpm: roll,
          skinId: won.skinId,
          inventoryItemId: inv.id,
          ledgerEntryId: entry.id,
          idempotencyKey,
        },
        include: { skin: true },
      });
    }, { isolationLevel: Prisma.TransactionIsolationLevel.ReadCommitted });

    return { opening, replayed: false };
  } catch (e) {
    // طلبان متزامنان بنفس المفتاح: الثاني يفشل بالقيد الفريد ثم يقرأ نتيجة الأول
    if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002") {
      const again = await findExisting(prisma, userId, idempotencyKey);
      if (again) return { opening: again, replayed: true };
    }
    throw e;
  }
}
