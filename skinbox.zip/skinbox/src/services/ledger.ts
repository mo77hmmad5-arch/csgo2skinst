import type { Prisma, LedgerType } from "@prisma/client";
import { AppError } from "../lib/errors.js";

type Tx = Prisma.TransactionClient;

/** يقفل صف المحفظة (FOR UPDATE) ويعيد الرصيد الحالي. يجب استدعاؤه داخل معاملة. */
export async function lockWallet(tx: Tx, userId: string) {
  const rows = await tx.$queryRaw<{ id: string; balance: number }[]>`
    SELECT id, balance FROM "Wallet" WHERE "userId" = ${userId} FOR UPDATE`;
  if (rows.length === 0) throw new AppError("NO_WALLET", "Wallet not found", 404);
  return rows[0];
}

/**
 * الطريقة الوحيدة لتغيير الرصيد: تكتب حركة في الدفتر وتحدّث المحفظة في المعاملة نفسها.
 * (مشغّل قاعدة البيانات يفحص التطابق عند COMMIT كطبقة حماية ثانية.)
 */
export async function postEntry(
  tx: Tx,
  wallet: { id: string; balance: number },
  p: {
    type: LedgerType;
    amount: number; // سالب للخصم
    idempotencyKey: string;
    refType?: string;
    refId?: string;
    meta?: Prisma.InputJsonValue;
  },
) {
  if (!Number.isInteger(p.amount) || p.amount === 0) throw new AppError("BAD_AMOUNT", "Invalid amount");
  const balanceAfter = wallet.balance + p.amount;
  if (balanceAfter < 0) throw new AppError("INSUFFICIENT_FUNDS", "Insufficient balance", 402);

  const entry = await tx.ledgerEntry.create({
    data: {
      walletId: wallet.id,
      type: p.type,
      amount: p.amount,
      balanceAfter,
      refType: p.refType,
      refId: p.refId,
      idempotencyKey: p.idempotencyKey,
      meta: p.meta,
    },
  });
  await tx.wallet.update({ where: { id: wallet.id }, data: { balance: balanceAfter } });
  return { entry, balanceAfter };
}
