import type { PrismaClient } from "@prisma/client";
import { validateOdds, type OddsItem } from "../lib/odds.js";
import { requirePermission } from "../lib/permissions.js";
import { AppError } from "../lib/errors.js";

/**
 * تعديل صندوق = إنشاء نسخة جديدة غير قابلة للتعديل ثم تحويل currentVersionId إليها.
 * النسخ القديمة تبقى كما هي لأن عمليات الفتح السابقة تشير إليها.
 */
export async function publishCaseVersion(
  prisma: PrismaClient,
  actorId: string,
  p: { caseId: string; price: number; items: OddsItem[]; reason: string; ip?: string },
) {
  await requirePermission(prisma, actorId, "cases:publish");
  validateOdds(p.items);
  if (!Number.isInteger(p.price) || p.price < 0) throw new AppError("BAD_PRICE", "Invalid price");
  if (!p.reason.trim()) throw new AppError("REASON_REQUIRED", "Reason required");

  return prisma.$transaction(async (tx) => {
    const box = await tx.case.findUniqueOrThrow({ where: { id: p.caseId } });
    const last = await tx.caseVersion.aggregate({ where: { caseId: p.caseId }, _max: { version: true } });
    const skins = await tx.skin.findMany({
      where: { id: { in: p.items.map((i) => i.skinId) }, isActive: true, deletedAt: null },
      select: { id: true },
    });
    if (skins.length !== p.items.length) throw new AppError("SKIN_UNAVAILABLE", "Some skins are inactive or missing");

    const version = await tx.caseVersion.create({
      data: {
        caseId: p.caseId,
        version: (last._max.version ?? 0) + 1,
        price: p.price,
        createdById: actorId,
        items: { create: p.items.map((i) => ({ skinId: i.skinId, weightPpm: i.weightPpm })) },
      },
    });
    await tx.case.update({ where: { id: p.caseId }, data: { currentVersionId: version.id } });
    await tx.auditLog.create({
      data: {
        actorId, action: "case.version.publish", entity: "Case", entityId: p.caseId,
        reason: p.reason, ip: p.ip,
        before: { currentVersionId: box.currentVersionId },
        after: { currentVersionId: version.id, price: p.price, items: p.items },
      },
    });
    return version;
  });
}
