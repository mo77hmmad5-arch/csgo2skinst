import { createHash, randomBytes } from "node:crypto";
import type { FastifyReply, FastifyRequest } from "fastify";
import { prisma } from "./db.js";

const COOKIE = "sid";
const TTL_MS = 7 * 24 * 3600 * 1000;
const hash = (t: string) => createHash("sha256").update(t).digest("hex");
const secure = process.env.NODE_ENV === "production" && process.env.INSECURE_COOKIES !== "1";

export async function startSession(req: FastifyRequest, reply: FastifyReply, userId: string) {
  const token = randomBytes(32).toString("base64url");
  await prisma.session.create({
    data: {
      userId, tokenHash: hash(token), ip: req.ip,
      userAgent: req.headers["user-agent"]?.slice(0, 200),
      expiresAt: new Date(Date.now() + TTL_MS),
    },
  });
  reply.setCookie(COOKIE, token, {
    httpOnly: true, sameSite: "lax", secure, path: "/", maxAge: TTL_MS / 1000,
  });
}

export async function currentUser(req: FastifyRequest) {
  const token = req.cookies[COOKIE];
  if (!token) return null;
  const s = await prisma.session.findUnique({ where: { tokenHash: hash(token) }, include: { user: true } });
  if (!s || s.revokedAt || s.expiresAt < new Date()) return null;
  return s.user;
}

export async function endSession(req: FastifyRequest, reply: FastifyReply) {
  const token = req.cookies[COOKIE];
  if (token) await prisma.session.updateMany({ where: { tokenHash: hash(token) }, data: { revokedAt: new Date() } });
  reply.clearCookie(COOKIE, { path: "/" });
}
