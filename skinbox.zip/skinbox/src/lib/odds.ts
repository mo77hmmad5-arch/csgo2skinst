import { randomInt } from "node:crypto";
import { AppError } from "./errors.js";

export const TOTAL_PPM = 1_000_000;

export interface OddsItem {
  skinId: string;
  weightPpm: number;
}

/** يتحقق أن النسخة صالحة للنشر: أوزان موجبة، بلا تكرار، ومجموعها 1,000,000 بالضبط. */
export function validateOdds(items: OddsItem[]): void {
  if (items.length === 0) throw new AppError("ODDS_EMPTY", "Case must contain items");
  const seen = new Set<string>();
  let sum = 0;
  for (const it of items) {
    if (!Number.isInteger(it.weightPpm) || it.weightPpm <= 0) {
      throw new AppError("ODDS_INVALID_WEIGHT", `Invalid weight for ${it.skinId}`);
    }
    if (seen.has(it.skinId)) throw new AppError("ODDS_DUPLICATE", `Duplicate skin ${it.skinId}`);
    seen.add(it.skinId);
    sum += it.weightPpm;
  }
  if (sum !== TOTAL_PPM) {
    throw new AppError("ODDS_SUM", `Weights sum to ${sum}, expected ${TOTAL_PPM}`);
  }
}

/** سحب عشوائي آمن تشفيريًا في [0, 1,000,000) بلا انحياز (rejection sampling داخل randomInt). */
export function rollPpm(): number {
  return randomInt(0, TOTAL_PPM);
}

/** يختار العنصر بالتجميع التراكمي. الترتيب حتمي (حسب skinId) ليكون التحقق لاحقًا ممكنًا. */
export function pickItem<T extends OddsItem>(items: T[], roll: number): T {
  if (!Number.isInteger(roll) || roll < 0 || roll >= TOTAL_PPM) {
    throw new AppError("ROLL_RANGE", "Roll out of range");
  }
  const sorted = [...items].sort((a, b) => (a.skinId < b.skinId ? -1 : 1));
  let acc = 0;
  for (const it of sorted) {
    acc += it.weightPpm;
    if (roll < acc) return it;
  }
  throw new AppError("ODDS_SUM", "Odds do not cover roll"); // لا يحدث بعد validateOdds
}
