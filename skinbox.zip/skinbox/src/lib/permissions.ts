import type { PrismaClient } from "@prisma/client";
import { AppError } from "./errors.js";

export const PERMISSIONS = [
  "skins:read", "skins:write",
  "cases:read", "cases:write", "cases:publish",
  "users:read", "users:moderate",
  "payments:read", "payments:refund", "payments:settings",
  "withdrawals:review", "withdrawals:approve_large",
  "support:handle",
  "reports:read",
  "audit:read",
] as const;
export type PermissionKey = (typeof PERMISSIONS)[number];

// فصل صلاحيات الكتالوج عن صلاحيات الأموال
export const ROLE_PERMISSIONS: Record<string, PermissionKey[]> = {
  super_admin: [...PERMISSIONS],
  catalog_manager: ["skins:read", "skins:write", "cases:read", "cases:write", "cases:publish", "reports:read"],
  payments_officer: ["payments:read", "payments:refund", "reports:read"],
  withdrawal_reviewer: ["withdrawals:review", "users:read", "payments:read"],
  support_agent: ["support:handle", "users:read"],
  analyst: ["skins:read", "cases:read", "users:read", "payments:read", "reports:read"],
};

/** يُستدعى في الخادم لكل عملية إدارية. لا تعتمد على إخفاء الأزرار في الواجهة. */
export async function requirePermission(
  prisma: PrismaClient,
  userId: string,
  key: PermissionKey,
): Promise<void> {
  const hit = await prisma.userRole.findFirst({
    where: { userId, role: { permissions: { some: { permission: { key } } } } },
    select: { userId: true },
  });
  if (!hit) throw new AppError("FORBIDDEN", `Missing permission ${key}`, 403);
}
