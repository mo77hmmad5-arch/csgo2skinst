import type { FastifyInstance } from "fastify";
import { randomUUID } from "node:crypto";
import { prisma } from "../lib/db.js";
import { AppError } from "../lib/errors.js";
import { lockWallet, postEntry } from "../services/ledger.js";
import { openCase } from "../services/openCase.js";
import { requireUser, SANDBOX } from "./auth.js";

const skinView = (s: { id: string; name: string; rarity: string; imageUrl: string; referencePrice: number }) => ({
  id: s.id, name: s.name, rarity: s.rarity, imageUrl: s.imageUrl, price: s.referencePrice,
});

export async function registerShopRoutes(app: FastifyInstance) {
  app.get("/api/cases", async () => {
    const cases = await prisma.case.findMany({
      where: { isPublished: true, currentVersionId: { not: null } },
      include: { currentVersion: { include: { items: { include: { skin: true } } } } },
      orderBy: { createdAt: "asc" },
    });
    return cases.map((c) => ({
      slug: c.slug, name: c.name, price: c.currentVersion!.price,
      preview: [...c.currentVersion!.items]
        .sort((a, b) => b.skin.referencePrice - a.skin.referencePrice)
        .slice(0, 3).map((i) => skinView(i.skin)),
    }));
  });

  app.get<{ Params: { slug: string } }>("/api/cases/:slug", async (req) => {
    const c = await prisma.case.findUnique({
      where: { slug: req.params.slug },
      include: { currentVersion: { include: { items: { include: { skin: true } } } } },
    });
    if (!c?.isPublished || !c.currentVersion) throw new AppError("CASE_UNAVAILABLE", "Case unavailable", 404);
    return {
      slug: c.slug, name: c.name, price: c.currentVersion.price, version: c.currentVersion.version,
      items: c.currentVersion.items
        .map((i) => ({ ...skinView(i.skin), percent: i.weightPpm / 10_000 }))
        .sort((a, b) => a.percent - b.percent),
    };
  });

  app.post<{ Params: { slug: string } }>(
    "/api/cases/:slug/open",
    { config: { rateLimit: { max: 30, timeWindow: "1 minute" } } },
    async (req) => {
      const user = await requireUser(req);
      const key = String(req.headers["idempotency-key"] ?? "");
      const box = await prisma.case.findUnique({ where: { slug: req.params.slug } });
      if (!box) throw new AppError("CASE_UNAVAILABLE", "Case unavailable", 404);
      const { opening, replayed } = await openCase(prisma, { userId: user.id, caseId: box.id, idempotencyKey: key });
      const w = await prisma.wallet.findUniqueOrThrow({ where: { userId: user.id } });
      return {
        replayed, balance: w.balance,
        opening: { id: opening.id, roll: opening.rollPpm, price: opening.price, skin: skinView(opening.skin) },
      };
    },
  );

  app.get("/api/inventory", async (req) => {
    const user = await requireUser(req);
    const items = await prisma.inventoryItem.findMany({
      where: { userId: user.id }, include: { skin: true }, orderBy: { acquiredAt: "desc" }, take: 200,
    });
    return items.map((i) => ({ id: i.id, status: i.status, acquiredAt: i.acquiredAt, skin: skinView(i.skin) }));
  });

  app.get("/api/wallet/ledger", async (req) => {
    const user = await requireUser(req);
    const w = await prisma.wallet.findUniqueOrThrow({ where: { userId: user.id } });
    const rows = await prisma.ledgerEntry.findMany({ where: { walletId: w.id }, orderBy: { seq: "desc" }, take: 50 });
    return { balance: w.balance, entries: rows.map((r) => ({ id: r.id, type: r.type, amount: r.amount, balanceAfter: r.balanceAfter, createdAt: r.createdAt })) };
  });

  // رصيد تجريبي عبر الدفتر. معطّل خارج وضع sandbox.
  app.post("/api/wallet/sandbox-topup", async (req) => {
    if (!SANDBOX) throw new AppError("DISABLED", "Not available", 404);
    const user = await requireUser(req);
    const result = await prisma.$transaction(async (tx) => {
      const wallet = await lockWallet(tx, user.id);
      if (wallet.balance >= 50_000) throw new AppError("TOPUP_LIMIT", "Sandbox balance is already high", 400);
      return postEntry(tx, wallet, { type: "SANDBOX_CREDIT", amount: 10_000, idempotencyKey: `topup:${randomUUID()}` });
    });
    return { balance: result.balanceAfter };
  });

  // بث عام لآخر النتائج (أسماء مقنّعة)
  app.get("/api/feed", async () => {
    const rows = await prisma.caseOpening.findMany({
      orderBy: { createdAt: "desc" }, take: 12, include: { skin: true, user: true, caseVersion: { include: { case: true } } },
    });
    return rows.map((r) => ({
      id: r.id, user: r.user.displayName.slice(0, 2) + "•••", case: r.caseVersion.case.name, skin: skinView(r.skin),
    }));
  });
}
