import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { prisma } from "../lib/db.js";
import { AppError } from "../lib/errors.js";
import { currentUser, endSession, startSession } from "../lib/session.js";

export const SANDBOX = process.env.PAYMENTS_MODE === "sandbox";

export async function requireUser(req: Parameters<typeof currentUser>[0]) {
  const u = await currentUser(req);
  if (!u) throw new AppError("UNAUTHENTICATED", "Login required", 401);
  return u;
}

export async function registerAuthRoutes(app: FastifyInstance) {
  app.get("/api/config", async () => ({ sandbox: SANDBOX }));

  app.get("/api/me", async (req) => {
    const u = await currentUser(req);
    if (!u) return { user: null };
    const w = await prisma.wallet.findUnique({ where: { userId: u.id } });
    return { user: { id: u.id, name: u.displayName, status: u.status }, balance: w?.balance ?? 0 };
  });

  // دخول تجريبي: متاح في وضع sandbox فقط. الدخول الحقيقي (Steam / Google) في المرحلة التالية.
  app.post("/api/auth/dev-login", { config: { rateLimit: { max: 10, timeWindow: "1 minute" } } }, async (req, reply) => {
    if (!SANDBOX) throw new AppError("DISABLED", "Not available", 404);
    const body = z.object({ name: z.string().trim().min(2).max(24), over18: z.literal(true) }).parse(req.body);
    const user = await prisma.user.create({
      data: { displayName: body.name, ageVerifiedAt: new Date(), wallet: { create: {} } },
    });
    await startSession(req, reply, user.id);
    return { ok: true };
  });

  app.post("/api/auth/logout", async (req, reply) => {
    await endSession(req, reply);
    return { ok: true };
  });
}
