import { describe, it, expect } from "vitest";
import { validateOdds, pickItem, rollPpm, TOTAL_PPM } from "../src/lib/odds";

const items = [
  { skinId: "a", weightPpm: 799_000 },
  { skinId: "b", weightPpm: 190_000 },
  { skinId: "c", weightPpm: 11_000 },
];

describe("odds", () => {
  it("accepts weights summing to 1,000,000", () => {
    expect(() => validateOdds(items)).not.toThrow();
  });
  it("rejects wrong sum, duplicates, empty and non-positive weights", () => {
    expect(() => validateOdds([{ skinId: "a", weightPpm: 999_999 }])).toThrow();
    expect(() => validateOdds([...items, { skinId: "a", weightPpm: 1 }])).toThrow();
    expect(() => validateOdds([])).toThrow();
    expect(() => validateOdds([{ skinId: "a", weightPpm: 0 }, { skinId: "b", weightPpm: TOTAL_PPM }])).toThrow();
  });
  it("picks by cumulative boundaries", () => {
    expect(pickItem(items, 0).skinId).toBe("a");
    expect(pickItem(items, 798_999).skinId).toBe("a");
    expect(pickItem(items, 799_000).skinId).toBe("b");
    expect(pickItem(items, 988_999).skinId).toBe("b");
    expect(pickItem(items, 989_000).skinId).toBe("c");
    expect(pickItem(items, 999_999).skinId).toBe("c");
    expect(() => pickItem(items, TOTAL_PPM)).toThrow();
  });
  it("rollPpm stays in range and empirical rates are close to configured odds", () => {
    const N = 200_000;
    const counts: Record<string, number> = { a: 0, b: 0, c: 0 };
    for (let i = 0; i < N; i++) {
      const r = rollPpm();
      expect(r).toBeGreaterThanOrEqual(0);
      expect(r).toBeLessThan(TOTAL_PPM);
      counts[pickItem(items, r).skinId]++;
    }
    expect(Math.abs(counts.a / N - 0.799)).toBeLessThan(0.01);
    expect(Math.abs(counts.b / N - 0.19)).toBeLessThan(0.01);
    expect(Math.abs(counts.c / N - 0.011)).toBeLessThan(0.005);
  });
});
