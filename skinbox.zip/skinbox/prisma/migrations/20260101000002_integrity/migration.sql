-- يُنفَّذ بعد الترحيل الأول: prisma migrate dev --name init
-- ثم أعد تسمية هذا المجلد ليأتي بعده زمنيًا (مثل 20260101000001_integrity).

-- 1) قيود القيم
ALTER TABLE "Wallet" ADD CONSTRAINT wallet_balance_nonneg CHECK (balance >= 0);
ALTER TABLE "CaseItem" ADD CONSTRAINT caseitem_weight_range CHECK ("weightPpm" > 0 AND "weightPpm" <= 1000000);
ALTER TABLE "CaseVersion" ADD CONSTRAINT caseversion_price_nonneg CHECK (price >= 0);

-- 2) جداول append-only: ممنوع UPDATE/DELETE
CREATE OR REPLACE FUNCTION forbid_mutation() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'Table % is append-only', TG_TABLE_NAME;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER ledger_immutable BEFORE UPDATE OR DELETE ON "LedgerEntry"
  FOR EACH ROW EXECUTE FUNCTION forbid_mutation();
CREATE TRIGGER opening_immutable BEFORE UPDATE OR DELETE ON "CaseOpening"
  FOR EACH ROW EXECUTE FUNCTION forbid_mutation();
CREATE TRIGGER audit_immutable BEFORE UPDATE OR DELETE ON "AuditLog"
  FOR EACH ROW EXECUTE FUNCTION forbid_mutation();
CREATE TRIGGER caseitem_immutable BEFORE UPDATE OR DELETE ON "CaseItem"
  FOR EACH ROW EXECUTE FUNCTION forbid_mutation();
-- CaseVersion: يُسمح بالإضافة فقط
CREATE TRIGGER caseversion_immutable BEFORE UPDATE OR DELETE ON "CaseVersion"
  FOR EACH ROW EXECUTE FUNCTION forbid_mutation();

-- 3) رصيد المحفظة يجب أن يطابق آخر حركة في الدفتر (يُفحص عند COMMIT)
--    أي تعديل للرصيد دون حركة موثقة يُفشل المعاملة كلها.
CREATE OR REPLACE FUNCTION wallet_matches_ledger() RETURNS trigger AS $$
DECLARE last_balance integer;
BEGIN
  SELECT "balanceAfter" INTO last_balance
    FROM "LedgerEntry" WHERE "walletId" = NEW.id ORDER BY seq DESC LIMIT 1;
  IF last_balance IS NULL THEN
    last_balance := 0;
  END IF;
  IF NEW.balance <> last_balance THEN
    RAISE EXCEPTION 'Wallet % balance (%) does not match ledger (%)', NEW.id, NEW.balance, last_balance;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE CONSTRAINT TRIGGER wallet_ledger_check
  AFTER INSERT OR UPDATE OF balance ON "Wallet"
  DEFERRABLE INITIALLY DEFERRED
  FOR EACH ROW EXECUTE FUNCTION wallet_matches_ledger();
