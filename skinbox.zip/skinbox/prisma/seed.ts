import { PrismaClient, type Rarity } from "@prisma/client";
import { PERMISSIONS, ROLE_PERMISSIONS } from "../src/lib/permissions.js";
import { validateOdds } from "../src/lib/odds.js";

const prisma = new PrismaClient();

const SKINS: { name: string; rarity: Rarity; price: number }[] = [
  { name: "Ashen Oath", rarity: "INDUSTRIAL", price: 40 },
  { name: "Iron Lotus", rarity: "MIL_SPEC", price: 90 },
  { name: "Velvet Ruin", rarity: "MIL_SPEC", price: 120 },
  { name: "Ember Drift", rarity: "RESTRICTED", price: 450 },
  { name: "Obsidian Veil", rarity: "CLASSIFIED", price: 1800 },
  { name: "Crimson Fang", rarity: "COVERT", price: 7500 },
  { name: "Night Sovereign", rarity: "COVERT", price: 15000 },
  { name: "Scarlet Dynasty", rarity: "CONTRABAND", price: 60000 },
];

// الأوزان بالجزء من المليون ومجموع كل صندوق 1,000,000
const CASES = [
  { slug: "ember", name: "صندوق الجمر", price: 299, items: [[0, 300000], [1, 300000], [2, 250000], [3, 110000], [4, 30000], [5, 10000]] },
  { slug: "dusk", name: "صندوق الغسق", price: 999, items: [[1, 250000], [2, 250000], [3, 300000], [4, 150000], [5, 40000], [6, 10000]] },
  { slug: "throne", name: "صندوق العرش", price: 2499, items: [[3, 600000], [4, 300000], [5, 80000], [6, 19000], [7, 1000]] },
] as const;

async function main() {
  for (const key of PERMISSIONS) await prisma.permission.upsert({ where: { key }, update: {}, create: { key } });
  for (const [name, keys] of Object.entries(ROLE_PERMISSIONS)) {
    const role = await prisma.role.upsert({ where: { name }, update: {}, create: { name } });
    for (const key of keys) {
      const perm = await prisma.permission.findUniqueOrThrow({ where: { key } });
      await prisma.rolePermission.upsert({
        where: { roleId_permissionId: { roleId: role.id, permissionId: perm.id } },
        update: {}, create: { roleId: role.id, permissionId: perm.id },
      });
    }
  }

  if (process.env.PAYMENTS_MODE !== "sandbox") return console.log("Roles seeded (demo catalog skipped).");

  const admin = await prisma.user.upsert({
    where: { email: "admin@example.test" }, update: {},
    create: { email: "admin@example.test", displayName: "Admin", ageVerifiedAt: new Date(), wallet: { create: {} } },
  });
  const superRole = await prisma.role.findUniqueOrThrow({ where: { name: "super_admin" } });
  await prisma.userRole.upsert({
    where: { userId_roleId: { userId: admin.id, roleId: superRole.id } },
    update: {}, create: { userId: admin.id, roleId: superRole.id },
  });

  const skinIds: string[] = [];
  for (const s of SKINS) {
    const found = await prisma.skin.findFirst({ where: { name: s.name } });
    const skin = found ?? await prisma.skin.create({
      data: { name: s.name, game: "demo", category: "blade", rarity: s.rarity, imageUrl: `/img/${s.name}.png`, referencePrice: s.price, priceSource: "seed" },
    });
    skinIds.push(skin.id);
  }

  for (const c of CASES) {
    if (await prisma.case.findUnique({ where: { slug: c.slug } })) continue;
    const items = c.items.map(([i, w]) => ({ skinId: skinIds[i], weightPpm: w }));
    validateOdds(items);
    const box = await prisma.case.create({ data: { slug: c.slug, name: c.name, isPublished: true } });
    const v = await prisma.caseVersion.create({ data: { caseId: box.id, version: 1, price: c.price, createdById: admin.id, items: { create: items } } });
    await prisma.case.update({ where: { id: box.id }, data: { currentVersionId: v.id } });
  }
  console.log("Seed complete.");
}

main().finally(() => prisma.$disconnect());
